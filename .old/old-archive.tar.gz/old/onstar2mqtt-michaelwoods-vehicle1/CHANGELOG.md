# Changelog

## 1.5.11

- Pickup latest upstream updates in [michaelwoods/onstar2mqtt v1.5.11](https://github.com/michaelwoods/onstar2mqtt/releases/tag/v1.5.11)

## 1.2.16

- Pickup latest upstream updates in [michaelwoods/onstar2mqtt v1.5.8](https://github.com/michaelwoods/onstar2mqtt/releases/tag/v1.5.8)

## 1.2.15

- Pickup latest upstream updates in [michaelwoods/onstar2mqtt v1.5.7](https://github.com/michaelwoods/onstar2mqtt/releases/tag/v1.5.7)

## 1.2.14

- Change add-on to use pre-built image instead of building locally

## 1.1.14

- Pickup latest upstream updates in [michaelwoods/onstar2mqtt v1.5.6](https://github.com/michaelwoods/onstar2mqtt/releases/tag/v1.5.6)

## 1.1.13

- Pickup latest upstream updates in [michaelwoods/onstar2mqtt v1.5.5](https://github.com/michaelwoods/onstar2mqtt/releases/tag/v1.5.5)

## 1.1.12

- Pickup latest upstream updates in michaelwoods/onstar2mqtt

## 1.1.11

- Pickup latest upstream updates in [michaelwoods/onstar2mqtt v1.5.4](https://github.com/michaelwoods/onstar2mqtt/releases/tag/v1.5.4)

## 1.1.10

- Pickup latest upstream updates in [michaelwoods/onstar2mqtt v1.5.3](https://github.com/michaelwoods/onstar2mqtt/releases/tag/v1.5.3)

## 1.1.9

- Pickup latest upstream updates - Fixed

## 1.1.8

- Pickup latest upstream updates

## 1.1.7

- Resolve image issue

## 1.1.6

- Signed Assets with CAS

## 1.1.5

- Added logo and icon files and matched numerical version with BigThunderSR/onstar2mqtt add-on numerical version

## 1.1.3

- Added option to provide a name for the vehicle using this integration

## 1.1.2

- Made some minor optimizations to the Dockerfile

## 1.1.1

- Created submodules structure to simplify maintenance and added ability to choose either BigThunderSR or michaelwoods build of onstar2mqtt
